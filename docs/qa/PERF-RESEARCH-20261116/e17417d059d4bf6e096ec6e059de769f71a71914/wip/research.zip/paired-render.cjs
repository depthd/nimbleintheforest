const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const {chromium}=require('playwright'),fs=require('node:fs');
const OUT=require('node:path').join(RESEARCH_ROOT, "results"),N=Number(process.env.N||5),ROUNDS=Number(process.env.ROUNDS||2);
function install(mode){
 const {G,THREE:T}=window.__game;let b=window.__pair;
 if(!b){
  const materials=new Map();G.scene.traverse(o=>{for(const m of Array.isArray(o.material)?o.material:[o.material])if(m&&!materials.has(m))materials.set(m,{compile:m.onBeforeCompile,key:m.customProgramCacheKey.bind(m)});});
  b=window.__pair={materials,chunk:T.ShaderChunk.lights_fragment_begin,ext:G.renderer.getContext().getExtension('EXT_disjoint_timer_query_webgl2'),partition:128,originalDirect:G.renderer.renderBufferDirect};
 }
 if(b.hidden){for(const [o,v] of b.hidden)o.visible=v;}b.hidden=[];
 if(b.orders){for(const [o,v] of b.orders)o.renderOrder=v;}b.orders=[];
 const hide=o=>{if(o){b.hidden.push([o,o.visible]);o.visible=false;}};
 if(mode==='no-terrain-diagnostic'){hide(G.terrain.group);hide(G.terrain.far);hide(G.terrain.backdrop);}
 if(mode==='no-far-diagnostic'){hide(G.terrain.far);hide(G.terrain.backdrop);}
 if(mode==='no-forest-diagnostic'){for(const k of G.forest.kinds)for(const m of k.meshes)hide(m);hide(G.forest.rockMesh);}
 if(mode==='far-last')for(const root of [G.terrain.far,G.terrain.backdrop])root.traverse(o=>{if(o.isMesh){b.orders.push([o,o.renderOrder]);o.renderOrder=o.name==='packed-snow-far'?2:1;}});
 if(mode==='packed-last')G.scene.traverse(o=>{if(o.name==='packed-snow'||o.name==='packed-snow-far'){b.orders.push([o,o.renderOrder]);o.renderOrder=2;}});
 if(mode==='backdrop16'&&!b.fineBackdrop){
  b.originalBackdrop=[...G.terrain.backdrop.children];const first=b.originalBackdrop[0],width=Math.round(Math.sqrt(first.geometry.attributes.position.count)),tiles=new Map();
  for(const mesh of b.originalBackdrop){const idx=mesh.geometry.index;for(let i=0;i<idx.count;i+=3){const a=idx.getX(i),bb=idx.getX(i+1),c=idx.getX(i+2),x=Math.min(a%width,bb%width,c%width),z=Math.min(Math.floor(a/width),Math.floor(bb/width),Math.floor(c/width)),key=`${Math.floor(x/16)},${Math.floor(z/16)}`;let list=tiles.get(key);if(!list)tiles.set(key,list=[]);list.push(a,bb,c);}}
  const p=new T.Vector3();b.fineBackdrop=[...tiles.values()].map(indices=>{const g=new T.BufferGeometry();for(const [k,a]of Object.entries(first.geometry.attributes))g.setAttribute(k,a);g.setIndex(indices);const box=new T.Box3();for(const i of indices)box.expandByPoint(p.fromBufferAttribute(g.attributes.position,i));const center=box.getCenter(new T.Vector3());let r=0;for(const i of indices)r=Math.max(r,p.fromBufferAttribute(g.attributes.position,i).distanceToSquared(center));g.boundingBox=box;g.boundingSphere=new T.Sphere(center,Math.sqrt(r));return new T.Mesh(g,first.material);});
 }
 if(b.originalBackdrop){G.terrain.backdrop.clear();G.terrain.backdrop.add(...(mode==='backdrop16'?b.fineBackdrop:b.originalBackdrop));}
 T.ShaderChunk.lights_fragment_begin=b.chunk;
 G.renderer.renderBufferDirect=b.originalDirect;
 G.sky.sun.shadow.mapSize.set(mode==='shadow1536'?1536:2048,mode==='shadow1536'?1536:2048);
 if(mode==='no-shadow-color')G.renderer.renderBufferDirect=function(camera,scene,geometry,material,object,group){const old=material.colorWrite;const skip=camera===G.sky.sun.shadow.camera&&this.shadowMap.type===T.PCFShadowMap&&this.getRenderTarget()?.depthTexture;if(skip)material.colorWrite=false;try{return b.originalDirect.call(this,camera,scene,geometry,material,object,group);}finally{material.colorWrite=old;}};
 if(mode==='zero-lights'){
  let chunk=b.chunk;
  for(const type of ['point','spot']){
   const assignment=`${type}Light = ${type}Lights[ i ];`;
   chunk=chunk.replace(assignment,assignment+`\n if (any(notEqual(${type}Light.color, vec3(0.0)))) {`);
   const from=chunk.indexOf(assignment),direct=chunk.indexOf('RE_Direct( directLight',from),end=chunk.indexOf(';',direct)+1;
   if(from<0||direct<0||end<1)throw Error('shader patch mismatch');
   chunk=chunk.slice(0,end)+'\n }'+chunk.slice(end);
  }
  T.ShaderChunk.lights_fragment_begin=chunk;
 }
 for(const [m,o] of b.materials){
  m.onBeforeCompile=function(sh,r){o.compile.call(this,sh,r);if(mode==='glint')sh.fragmentShader=sh.fragmentShader.replace('    // sun glints on the snow','    if (camDist < 28.0 && uGlint > 0.0 && rockK < 1.0) {\n    // sun glints on the snow').replace('    outgoingLight += vec3(g * 1.2);','    outgoingLight += vec3(g * 1.2);\n    }');};
  m.customProgramCacheKey=()=>o.key()+'-paired-'+(['glint','zero-lights'].includes(mode)?mode:'base');m.needsUpdate=true;
 }
 const partition=mode==='forest32'?32:128;
 if(partition!==b.partition){
  for(const k of G.forest.kinds){const ins=k.instances;if(!ins)continue;
   for(const parts of ins.chunks.values())ins.release(parts);ins.chunks.clear();
   if(!ins.researchOriginal){const map=ins.chunks;ins.researchOriginal={add:ins.add,get:map.get.bind(map),set:map.set.bind(map)};
    ins.add=function(matrix){this.researchKey=`${Math.floor(matrix.elements[12]/this.researchPartition)},${Math.floor(matrix.elements[14]/this.researchPartition)}`;return this.researchOriginal.add.call(this,matrix);};
    map.get=()=>ins.researchOriginal.get(ins.researchKey);map.set=(_,v)=>ins.researchOriginal.set(ins.researchKey,v);
   }
   ins.researchPartition=partition;
  }
  b.partition=partition;G.forest.update(G.player.pos,true);
 }
 G.renderer.shadowMap.enabled=mode!=='no-shadows-diagnostic';b.mode=mode;b.samples=[];b.queries=[];
}
function setup(name){
 const {G,THREE:T}=window.__game;G.time=46800;G.settings.weatherLock=name==='blizzard'?'blizzard':'clear';G.weather.setType(G.settings.weatherLock,true);G.weather.update(0,0);
 let x=4.1797120010727955,y=6.213871299659598,z=14.95711265998241,target=new T.Vector3(0,G.house.Y0+1,0);
 if(name==='home'){x=0;y=G.house.Y0+.03;z=1.5;target.set(-3.6,G.house.Y0+1,-3.25);}
 if(name==='forest'||name==='blizzard'){x=110;z=48;y=G.terrain.heightAt(x,z)+.15;target.set(x+8,y+1,z-10);}
 if(name==='overview'){x=80;z=80;y=G.terrain.heightAt(x,z)+160;target.set(0,G.house.Y0,0);}
 window.__game.teleport(x,y,z);window.__game.lookAt(...target.toArray());G.player.updateCamera(0);G.sky.indoorFactor=name==='home'?.5:1;G.sky.update();G.terrain.update(G.camera.position,400);G.forest.update(G.player.pos,true);G.cliffs?.update(G.camera.position,G.player.pos,Infinity);G.entities.cull(1,G.camera.position);G.lake.stream(G.player.pos,60);G.corpses.update();G.snow.renderer.update(G.player.pos);G.camera.updateMatrixWorld(true);
}
if(require.main===module)(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{
 const page=await browser.newPage({viewport:{width:640,height:360},deviceScaleFactor:1}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.requestAnimationFrame=()=>0;let s=123456789;Math.random=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};});
 const start=Date.now();await page.goto('http://127.0.0.1:5196/?test=1&seed=42&hour=13&weather=clear');await page.waitForFunction(()=>window.__game,null,{timeout:300000,polling:100});
 const result={readyMs:Date.now()-start,N,ROUNDS,errors,runs:[]};console.log('ready',result.readyMs);
 const scenarios=(process.env.SCENARIOS||'spawn,forest,blizzard').split(',');
 for(const name of scenarios){await page.evaluate(setup,name);
  for(let round=0;round<ROUNDS;round++){
   const modes=(process.env.MODES||'base,glint,zero-lights,forest32').split(',');if(round%2)modes.reverse();
   for(const mode of modes){await page.evaluate(install,mode);
    for(let i=-2;i<N;i++)await page.evaluate(measured=>{
     const {G}=window.__game,b=window.__pair,r=G.renderer,gl=r.getContext(),q=b.ext?gl.createQuery():null;
     if(q)gl.beginQuery(b.ext.TIME_ELAPSED_EXT,q);const t=performance.now();r.clear();r.render(G.scene,G.camera);const submit=performance.now()-t;if(q)gl.endQuery(b.ext.TIME_ELAPSED_EXT);gl.readPixels(0,0,1,1,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array(4));const complete=performance.now()-t;
     if(measured){b.samples.push({submit,complete,calls:r.info.render.calls,triangles:r.info.render.triangles,points:r.info.render.points});if(q)b.queries.push(q);}else if(q)gl.deleteQuery(q);
    },i>=0);
    const data=await page.evaluate(()=>{
     const {G}=window.__game,b=window.__pair,gl=G.renderer.getContext();const gpu=b.queries.map(q=>{const v=!gl.getParameter(b.ext.GPU_DISJOINT_EXT)&&gl.getQueryParameter(q,gl.QUERY_RESULT_AVAILABLE)?gl.getQueryParameter(q,gl.QUERY_RESULT)/1e6:null;gl.deleteQuery(q);return v;});
     G.renderer.clear();G.renderer.render(G.scene,G.camera);gl.finish();const p=new Uint8Array(gl.drawingBufferWidth*gl.drawingBufferHeight*4);gl.readPixels(0,0,gl.drawingBufferWidth,gl.drawingBufferHeight,gl.RGBA,gl.UNSIGNED_BYTE,p);let h=2166136261;for(const v of p)h=Math.imul(h^v,16777619)>>>0;let s='';for(let i=0;i<p.length;i+=32768)s+=String.fromCharCode(...p.subarray(i,i+32768));
     return {samples:b.samples,gpu,hash:h,raw:btoa(s),memory:G.renderer.info.memory,position:G.camera.position.toArray(),quaternion:G.camera.quaternion.toArray(),lights:G.fx.lights.map(l=>l.intensity),spot:G.fx.spot.intensity};
    });
    fs.writeFileSync(`${OUT}/${process.env.PREFIX||'paired'}-${name}-${round}-${mode}.rgba`,Buffer.from(data.raw,'base64'));delete data.raw;
    result.runs.push({name,round,mode,...data});fs.writeFileSync(`${OUT}/${process.env.PREFIX||'paired'}-render.json`,JSON.stringify(result,null,2));console.log(name,round,mode,JSON.stringify(data));
   }
  }
 }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});

module.exports={install,setup};
