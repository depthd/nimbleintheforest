const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const {chromium}=require('playwright'),fs=require('node:fs');
const OUT=require('node:path').join(RESEARCH_ROOT, "results"),N=Number(process.env.N||900),label=process.argv[2]||'base';
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{
 const page=await browser.newPage({viewport:{width:640,height:360},deviceScaleFactor:1}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.__realNow=performance.now.bind(performance);window.__time=1000;Object.defineProperty(performance,'now',{value:()=>window.__time});window.requestAnimationFrame=cb=>{window.__next=cb;return 1;};let s=123456789;Math.random=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};});
 const start=Date.now();await page.goto((process.env.URL||'http://127.0.0.1:5196/')+'?test=1&seed=42&hour=13&weather=clear&warmup=0');await page.waitForFunction(()=>window.__game,null,{timeout:300000,polling:100});
 const result={label,N,readyWithoutGraphicsMs:Date.now()-start,errors,scenarios:{}};
 await page.evaluate(()=>{
  const {G}=window.__game,real=window.__realNow,s=window.__cpu={current:{},samples:[],enabled:false};
  const wrap=(o,k,name)=>{if(!o||typeof o[k]!=='function')return;const old=o[k];o[k]=function(...args){const t=real();try{return old.apply(this,args);}finally{if(s.enabled)s.current[name]=(s.current[name]||0)+real()-t;}};};
  for(const key of ['weather','fires','thermal','lake','build','body','entities','resting','forest','player','snow','terrain','cliffs','structures','corpses','animals','interact','sky','fx','vm','audio','hud'])for(const method of ['update','step','stream','sync','updateFalling','physics','updateCamera','cull'])wrap(G[key],method,key+'.'+method);
  wrap(G.world,'step','world.step');wrap(G.player.avatar,'update','avatar.update');wrap(G.player.avatar,'renderHands','avatar.renderHands');wrap(G.snow.renderer,'refresh','trail.refresh');wrap(G.snow,'raycast','snow.raycast');wrap(G.terrain,'geometryFromData','terrain.install');
  G.renderer.render=()=>{};G.renderer.clear=()=>{};
 });
 for(const name of (process.env.SCENARIOS||'home,forest,overview,blizzard,pile,chop').split(',')){
  const setup=await page.evaluate(name=>{
   const api=window.__game,{G,THREE:T}=api,s=window.__cpu;s.samples=[];s.enabled=false;s.route=null;s.action=null;G.paused=false;G.input.keys.clear();G.settings.weatherLock=name.startsWith('blizzard')?'blizzard':'clear';G.weather.setType(G.settings.weatherLock,true);
   if(name==='home'){api.teleport(0,G.house.Y0+.03,1.5);api.lookAt(-3.6,G.house.Y0+1,-3.25);s.action=i=>{if(i%120===0){G.house.door.data.open=!G.house.door.data.open;const w=G.house.windows[i/120%G.house.windows.length|0];if(w.data.glass==='intact')G.house.breakGlass(w);}};}
   if(name==='forest'||name==='blizzard')s.route=i=>{const x=106+(.12*(i%900<450?i%900:900-i%900)),z=48;api.teleport(x,G.terrain.heightAt(x,z)+.12,z);api.lookAt(x+8,G.terrain.heightAt(x,z)+1,z-10);};
   if(name.endsWith('-walk')){
    let z=48;for(let candidate=40;candidate<90;candidate+=2){let clear=true;for(let x=120;x<=142;x+=1)if(G.forest.treesNear(x,candidate,1).length||G.region.slopeAt(x,candidate)>.4||Number.isFinite(G.region.waterAt(x,candidate))){clear=false;break;}if(clear){z=candidate;break;}}
    api.teleport(120,G.terrain.heightAt(120,z)+.15,z);G.player.yaw=-Math.PI/2;G.player.pitch=-.16;G.input.enabled=true;G.input.locked=true;G.input.keys.add('KeyW');
    s.route=i=>{G.player.yaw=i<800?-Math.PI/2:Math.PI/2;};
   }
   if(name==='overview'){api.teleport(80,G.terrain.heightAt(80,80)+160,80);api.lookAt(0,G.house.Y0,0);G.paused=true;}
   if(name==='pile'){api.teleport(12,G.terrain.heightAt(12,10)+.1,10);api.lookAt(16,G.terrain.heightAt(16,10)+.5,10);for(let i=0;i<100;i++)G.entities.spawnItem('log',new T.Vector3(16+(i%5)*.22,G.terrain.heightAt(16,10)+1+Math.floor(i/25)*.25,10+(Math.floor(i/5)%5)*.22));}
   if(name==='chop'){
    api.give('axe');api.equip('axe');const tr=G.forest.treesNear(0,0,120).filter(t=>t.alive&&['spruce','pine'].includes(t.type)&&t.r>.09&&t.r<.17&&Math.hypot(t.x,t.z)>18&&G.region.slopeAt(t.x,t.z)<.25).sort((a,b)=>Math.hypot(a.x,a.z)-Math.hypot(b.x,b.z))[0];
    s.tree=tr;const x=tr.x-Math.cos(tr.leanDir)*1.1,z=tr.z-Math.sin(tr.leanDir)*1.1;G.forest.update(new T.Vector3(tr.x,tr.y,tr.z),true);api.teleport(x,G.terrain.heightAt(x,z)+.05,z);api.lookAt(tr.x,tr.y+.9,tr.z);
    s.action=i=>{if(tr.alive&&i%8===0){api.lookAt(tr.x,tr.y+.9,tr.z);api.swing();}};
   }
   return {position:G.player.pos.toArray(),heap:performance.memory.usedJSHeapSize,tree:s.tree?{id:s.tree.id,alive:s.tree.alive}:null};
  },name);
  const cdp=await page.context().newCDPSession(page);await cdp.send('Profiler.enable');await cdp.send('Profiler.start');
  for(let at=-30;at<N;at+=15)await page.evaluate(({at,N})=>{
   const s=window.__cpu,real=window.__realNow;
   for(let i=at;i<Math.min(at+15,N);i++){
    s.enabled=i>=0;s.current={};const begin=real();s.route?.(Math.max(i,0));s.action?.(i);window.__time+=1000/60;window.__next(window.__time);if(i>=0)s.samples.push({frame:i,total:real()-begin,...s.current});
   }
  },{at,N});
  const {profile}=await cdp.send('Profiler.stop');await cdp.send('HeapProfiler.collectGarbage');const retainedHeap=await cdp.send('Runtime.getHeapUsage');fs.writeFileSync(`${OUT}/cpu-${label}-${name}.cpuprofile`,JSON.stringify(profile));await cdp.detach();
  result.scenarios[name]=await page.evaluate(()=>{
   const {G}=window.__game,s=window.__cpu;s.enabled=false;
   const hash=a=>{let h=2166136261;const bytes=new Uint8Array(a.buffer,a.byteOffset,a.byteLength);for(const v of bytes)h=Math.imul(h^v,16777619)>>>0;return h;};
   return {samples:s.samples,heap:performance.memory.usedJSHeapSize,position:G.player.pos.toArray(),time:G.time,thermalHash:[hash(G.thermal.T),hash(G.thermal.AH),hash(G.thermal.draft)],terrain:G.terrain.streamingStats(),snow:G.snow.renderer.stats(),field:G.snow.field.stats(),snowHashes:[...G.snow.renderer.entries.values()].map(e=>hash(e.pixels)),physics:{bodies:G.world.bodies.len(),colliders:G.world.colliders.len()},tree:s.tree?{id:s.tree.id,alive:s.tree.alive}:null};
  });result.scenarios[name].setup=setup;result.scenarios[name].retainedHeap=retainedHeap;
  fs.writeFileSync(`${OUT}/cpu-${label}.json`,JSON.stringify(result,null,2));const a=result.scenarios[name].samples.map(s=>s.total).sort((a,b)=>a-b);console.log(label,name,JSON.stringify({p50:a[Math.floor(N*.5)],p95:a[Math.floor(N*.95)],p99:a[Math.floor(N*.99)],max:a.at(-1),terrain:result.scenarios[name].terrain,snow:result.scenarios[name].snow,tree:result.scenarios[name].tree}));
 }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
