from pathlib import Path
import json, statistics, csv, html, subprocess, shutil, base64, hashlib, os
ROOT=Path(os.environ.get("RESEARCH_ROOT",Path(__file__).resolve().parent))
R=ROOT/'results'; OUT=ROOT/'report'; OUT.mkdir(exist_ok=True)
BASE='e17417d059d4bf6e096ec6e059de769f71a71914'
def read(name):
 p=R/name
 return json.loads(p.read_text()) if p.exists() else None
def stats(values):
 a=sorted(v for v in values if isinstance(v,(int,float)))
 if not a:return None
 return dict(n=len(a),p50=statistics.median(a),p95=a[min(len(a)-1,int(len(a)*.95))],p99=a[min(len(a)-1,int(len(a)*.99))],max=a[-1],mean=statistics.mean(a))
def sample(s,key='total'):return stats([x.get(key,0) for x in s['samples']])
def fmt(n):return f'{n:.2f}'.rstrip('0').rstrip('.') if isinstance(n,(int,float)) else str(n)
def seq(s):return ' / '.join(fmt(s[k]) for k in ['p50','p95','p99','max']) if s else '—'
def esc(x):return html.escape(str(x))
def table(headers,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def gpu_summary(name):
 d=read(name);groups={}
 if not d:return []
 for r in d['runs']:
  k=(r['name'],r['mode']);groups.setdefault(k,[]).extend(x['complete'] for x in r['samples'])
 return [[esc(n),esc(m),stats(v)['n'],seq(stats(v))] for (n,m),v in groups.items()]
cpu=read('cpu-base.json'); native=read('survey.json'); snow=read('cpu-snow-reader.json'); walk=read('cpu-base-walk.json'); walknew=read('cpu-snow-reader-walk.json')
summary_rows=[]; cpu_rows=[]
for label,data in [('base',cpu),('snow-reader',snow),('base-walk',walk),('snow-reader-walk',walknew),('base-home',read('cpu-base-home.json')),('thermal-aggregate-home',read('cpu-thermal-aggregate-home.json'))]:
 if not data:continue
 for scenario,s in data['scenarios'].items():
  for k in set().union(*(x.keys() for x in s['samples']))-{'frame'}:
   st=sample(s,k);summary_rows.append({'run':label,'scenario':scenario,'metric':k,**st})
  cpu_rows.append([label,scenario,len(s['samples']),seq(sample(s))])
with (OUT/'cpu-summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['run','scenario','metric','n','p50','p95','p99','max','mean']);w.writeheader();w.writerows(summary_rows)
nativerows=[]
partial=read('survey-spawn-partial.json')
if partial:nativerows.append(['spawn',len(partial['samples']),seq(sample(partial,'interval')),seq(sample(partial))])
for n,s in native['scenarios'].items():nativerows.append([n,len(s['samples']),seq(sample(s,'interval')),seq(sample(s))])
all_gpu=[]
for f in ['paired-render.json','pcf-render.json','gpu-diagnostic-render.json','backdrop-render.json','far-order-render.json']:
 all_gpu.extend([[f]+row for row in gpu_summary(f)])
with (OUT/'gpu-summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['protocol','scenario','variant','n','p50 / p95 / p99 / max ms']);w.writerows(all_gpu)
branches={}
for line in subprocess.check_output(['git','for-each-ref','--format=%(refname:short) %(objectname)','refs/heads/task/PERF-RESEARCH-20261116*'],cwd=ROOT/'repo',text=True).splitlines():
 name,sha=line.split()
 if name!='task/PERF-RESEARCH-20261116':branches[name]=sha
(OUT/'versions.json').write_text(json.dumps({'base':BASE,'branches':branches},indent=2))
eq=[]
for n,a in walk['scenarios'].items():
 b=walknew['scenarios'][n]
 eq.append([n,a['snowHashes']==b['snowHashes'],a['thermalHash']==b['thermalHash'],a['position']==b['position'],a['physics']==b['physics'],a['field']['modifiedCells']])
thermal=read('thermal-aggregate.json');denom=read('thermal-denominators.json')
thermrows=[]
for title,data in [('Суммы знаменателей (отклонено)',denom),('Агрегаты (кандидат)',thermal)]:
 for variant in ['base','candidate']:
  samples=[x for r in data if r['name']==variant for x in r['samples']]
  thermrows.append([title,variant,len(samples),seq(stats(samples))])
motion=read('motion-visual.json')
pixelrows=[]
try:
 import numpy as np
 from PIL import Image
 for proto in ['paired','pcf','gpu-diagnostic','backdrop','far-order']:
  for p in R.glob(proto+'-*-base.rgba'):
   stem=p.stem[:-5];a=np.fromfile(p,np.uint8).reshape(360,640,4)
   for q in R.glob(stem+'-*.rgba'):
    if q==p:continue
    b=np.fromfile(q,np.uint8).reshape(a.shape);delta=np.abs(a.astype(int)-b.astype(int));pixelrows.append([p.name,q.name,int(np.any(delta[:,:,:3],axis=2).sum()),int(delta.max()),float(delta[:,:,:3].mean())])
 for p in R.glob('motion-*-base.rgba'):
  stem=p.stem[:-5];a=np.fromfile(p,np.uint8).reshape(360,640,4)
  for q in R.glob(stem+'-*.rgba'):
   if q==p:continue
   b=np.fromfile(q,np.uint8).reshape(a.shape);d=np.abs(a.astype(int)-b.astype(int));pixelrows.append([p.name,q.name,int(np.any(d[:,:,:3],axis=2).sum()),int(d.max()),float(d[:,:,:3].mean())])
 for name in ['pcf-spawn-0-base','pcf-spawn-0-shadow1536','motion-3-base','motion-3-shadow1536','motion-3-no-shadow-color']:
  p=R/(name+'.rgba')
  if p.exists():Image.fromarray(np.fromfile(p,np.uint8).reshape(360,640,4)[::-1]).save(OUT/(name+'.png'))
 a=(R/'active-lights-base.rgba').read_bytes();b=(R/'active-lights-zero-lights.rgba').read_bytes()
 aa=np.frombuffer(a,np.uint8).reshape(360,640,4);bb=np.frombuffer(b,np.uint8).reshape(aa.shape);dd=np.abs(aa.astype(int)-bb.astype(int));pixelrows.append(['active-lights-base.rgba','active-lights-zero-lights.rgba',int(np.any(dd[:,:,:3],axis=2).sum()),int(dd.max()),float(dd[:,:,:3].mean())])
except ImportError:pass
with (OUT/'pixel-comparison.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['base','variant','changed RGB pixels of 230400','max channel difference / 255','mean absolute RGB difference / 255']);w.writerows(pixelrows)
def image(name,caption):
 p=OUT/name
 if not p.exists():return ''
 return '<figure><img alt="'+esc(caption)+'" src="data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()+'"><figcaption>'+esc(caption)+'</figcaption></figure>'
body='''<h1>Исследование производительности nimbleintheforest</h1>
<p>16 ноября 2026 · локальные изолированные эксперименты · ничего не отправлено и не объединено.</p>
<p><b>Решение:</b> первой стоит переносить scoped-reader снежных плиток; второй локальный кандидат — устранение повторных обходов тепловых агрегатов. Его компонентный выигрыш подтверждён, общий кадр — нет. Третье направление — фоновая полная погодная пересборка снежных текстур; это архитектурная гипотеза, а не измеренное ускорение. У проверенных графических настроек и микропроб нет надёжного общего выигрыша. Аппаратный GPU в этой среде отсутствует.</p>
<h2>Три следующих изменения</h2>'''
body+=table(['Приоритет и код','Доказательство','Цена, качество и ограничения'],[
 ['1. <code>SnowField.gridReader</code> + <code>SnowTrailRenderer.refresh</code>', 'Настоящая ходьба в метели, 1200 кадров без рендера: CPU-кадр 10,5 → 9,5 мс; p95 27 → 23; p99 33,3 → 31,4. Медиана самого refresh 6,2 → 5,1 мс.','Небольшая правка. Контрольные суммы всех текстур и тепловых полей, физические счётчики и конечная позиция совпали. Кэш живёт только один refresh; покрытие не кэшируется между кадрами. Выигрыш FPS с GPU не измерен.'],
 ['2. <code>Thermal.aggregate</code>','Четыре последовательные пары по 1200 вызовов Node: медиана update примерно 0,88 → 0,79 мс. В production Chromium ABBA-пары: 0,99 → 0,91 и 1,01 → 0,96 мс (медиана update). Все массивы, поверхности, иней и агрегаты точно совпали на 300 изменениях состояния.','Небольшая/средняя правка (~60 строк diff). Убирает повторные входные расчёты и обходы, сохраняет порядок суммирования. Это около 0,05–0,1 мс подсистемы; p99 в одном раунде ухудшился. Отдельная полная CPU-пара дома дала медиану 3,8 → 4,4 мс, среднее 5,28 → 4,84; целый кадр устойчиво не ускорен. Не устранение всех подёргиваний.'],
 ['3. Полный погодный refresh в Worker; контактный частичный — в текущем кадре','В настоящей ходьбе метель тратит на refresh в среднем около 8 мс CPU на кадр; p99 около 28 мс. Это подтверждённая дорогая работа. Ускорение нового Worker НЕ измерено.','Высокая сложность: снимки полей и укрытий, ревизии/отмена, запрет устаревшего результата после контакта, бюджет загрузки текстур. Возможен визуальный лаг/швы при неверной интеграции. Не смешивать с уже существующим Worker рельефа.'],
])
body+='''<p>Проценты разных проб не складывались. Общая версия с двумя CPU-изменениями не собиралась: они независимы и сохранены отдельными ветками. Переносить выборочно после QA нужного SHA.</p>
<h2>База и границы работы</h2><p>Репозиторий <code>depthd/nimbleintheforest</code>; интеграционная ветка <code>claude/friendly-archimedes-onmybq</code>. Точная база: <code>'''+BASE+'''</code>. Прочитаны AGENTS.md, .coord/repository.json, docs/PERFORMANCE.md, docs/PERF-001.md. Унаследованы Worker рельефа, fallback с бюджетом, гистерезис/кэш LOD, 128-метровые группы леса, обновление только изменённых матриц, объединение тел и неподвижного дерева, fixed body построек, кэш статики, MAX_STEPS=3, ревизии/очередь следов и прогрев материалов при запуске.</p>
<p>Работа шла в отдельном клоне <code>work/perf-research/repo</code>. Общий checkout остаётся на <code>work</code> и исходном SHA, без изменений отслеживаемых файлов. В начале там была пересоздана только игнорируемая локальная сборка dist того же исходного SHA; последующие сборки и исходниковые пробы изолированы. Ни push, ни merge, ни публикации не выполнялись.</p>
<h2>Окружение и протокол</h2>
<ul><li>Linux x86-64; Intel Xeon Platinum 8573C, 5 видимых vCPU, cgroup quota 4 CPU; память cgroup 16 GiB; /dev/dri отсутствует.</li>
<li>Node 24.22.1, npm 11.9.0, Chromium 156.0.8078.79, WebGL2, ANGLE Vulkan SwiftShader Device (Subzero). Программная графика конкурирует с JS за CPU. Эти секунды на кадр не являются FPS видеокарты игрока.</li>
<li>Все A/B: production Vite build, 640×360, DPR 1, штатный MSAA и PCF 2048², исходный мир 3072 м. Seed 42; Math.random для диагностик — фиксированный LCG 123456789. Графические пробы: 13:00, фиксированная ясная погода или мгновенно установленная метель, одинаковые позиция/кватернион камеры и экспозиция 1 в пределах каждой пары.</li>
<li>Частота физики, графическая дальность, густота, геометрия, симуляция и эффекты в рекомендуемых CPU-пробах сохранены. Отключения категорий ниже — только диагностика, не варианты оптимизации.</li>
<li>Нативный RAF: 80 кадров старта и по 20 остальных, после прогрева; записаны интервал RAF, полное время JS callback и подсистемы. В 20 кадрах p95/p99 почти равны максимуму: хвост статистически слабый. В медленной среде штатный clamp dt=0,1 и максимум три шага ограничивают симуляцию.</li>
<li>CPU-протокол: настоящий callback игры, детерминированные 1/60 с, renderer.render/clear отключены, graphics warmup=0, 30 прогревочных и 900/1200 измеренных кадров. Это стоимость симуляции/обновлений, без обхода сцены внутри renderer и без GPU, а не FPS. Между небольшими пачками вызывается браузер, Worker получает реальные ответы.</li>
<li>GPU-протокол: замороженная симуляция; последовательно render → readPixels(1×1) как барьер завершения, плюс EXT_disjoint_timer_query_webgl2. Два прогревочных рендера на вариант; малые выборки 3–5 кадров, для основных проб прямой и обратный порядок. Полные RGBA-снимки сравниваются в той же сцене. runtime-патчи исключают дрейф генерации и камеры; эквивалентные исходниковые варианты также собраны и имеют SHA ниже.</li>
<li>Первый несинхронизированный графический прогон исключён: одного gl.finish в наблюдаемом протоколе оказалось недостаточно — возвращались времена отправки команд вместо завершения. Исправленный барьер даёт секунды, согласованные с GPU queries. Отбракованные данные сохранены в discarded-unsynchronized, в таблицах они не используются.</li></ul>
<h2>Загрузка отдельно от прогретой игры</h2>
<p>Холодный контекст базовой production-сборки: готовность 42,836 с; startup-graphics 27,724 с (6 штатных ракурсов и compileAsync). Другие отдельные старты ~39–42 с. Это одна облачная машина и локальный HTTP: сеть игрока не моделировалась. Убирать штатный прогрев ради красивого времени загрузки не предлагается. CPU-замеры с warmup=0 не входят в эти числа.</p>
<h2>Нативный RAF — общая картина</h2><p>Все времена в мс. Формат: медиана / p95 / p99 / максимум.</p>'''
body+=table(['Сценарий','Кадры','Интервал RAF','JS callback'],nativerows)
body+='''<p>В профиле дома около 97% времени главный поток idle, в ожидании программной графики. GPU queries замороженного кадра подтверждают примерно 3,2–3,5 с. Это графическое ограничение SwiftShader; JS callback в десятки миллисекунд сам по себе не объясняет такой интервал.</p>
<h2>CPU — воспроизводимые сценарии</h2>
<p>home: внутри дома (0,Y0+0,03,1,5), открытие двери и разбитие окон по фиксированным кадрам. forest: диагностический проход позиций через x=128; не обычная ходьба. overview: диагностическая камера на 160 м над землёй, симуляция приостановлена. blizzard: такой же проход позиций с метелью и существующими следами/ямами. pile: 100 пересекающихся физических брёвен; chop: настоящее попадание топором по выбранной ели, дерево повалено. Эти сценарии идут последовательно, состояние между ними намеренно сохраняется.</p>
<p>Дополнительные forest-walk/blizzard-walk — настоящая ходьба KeyW, один teleport только для постановки, x=120,z=40, разворот по кадру; пересечена граница x=128. 20 секунд симуляции на сценарий. Образуется 21–22,5 тысячи изменённых снежных ячеек, поле и текстуры сохранены.</p>'''
body+=table(['Версия','Сценарий','Кадры','CPU-кадр: медиана / p95 / p99 / max'],cpu_rows)
body+=table(['Сценарий ходьбы','FNV32 текстур совпали','FNV32 тепла совпали','Позиция совпала','Bodies/colliders совпали','Изменённых ячеек'],eq)
body+='''<p>В настоящей ходьбе без метели новый reader почти не меняет медиану (4,9 → 4,7 мс); p99 15,1 → 16,5 мс ухудшился. Полезный случай — погодные полные refresh. В исходной метели их средняя стоимость 8,03 мс, p95 22,1, p99 28,3; после — 6,61 / 18,3 / 25,4 мс. Пики полностью не устранены.</p>
<h2>Проверенные CPU-идеи</h2>'''
body+=table(['Проба','Версия','Вызовы','update: медиана / p95 / p99 / max'],thermrows)
production=read('thermal-production.json')
if production:body+=table(['Production-класс, ABBA','Блоки по 10 update','Медиана / p95 / p99 / max'],[[r['name'],len(r['samples']),seq(stats(r['samples']))] for r in production])
body+='''<p><b>Снег.</b> В src/world/snow-field.ts каждый gridState строил строковый адрес и искал ту же плитку для каждой 4-см ячейки. Новый reader живёт только в одном refresh: для полного 89×89 stencil поиск плитки нужен при переходе между участками строки, а не 7921 раз. Толщина подложки по-прежнему пересчитывается, состояние холодных архивных ячеек и формулы weathered не меняются. 900 точных сравнений текстур, bounds и visibility с исходным renderer включают погоду, rewind, холодные плитки, знаковые границы и изменяемое укрытие. Добавлена одна временная closure; постоянный кэш не растёт. Фактическая отдельная экономия GC не изолирована.</p>
<p><b>Тепло.</b> Исходный aggregate повторял подготовку окон/утечек и обход всех faces для каждой зоны, а клетки обходились отдельно для средних и источников. Проба передаёт уже готовые входы update и считает обе зоны одним проходом, сохраняя порядок каждого суммирования. Отдельная первая идея — суммировать знаменатели solver заранее — дала точные данные, но в нескольких парах стала медленнее; она отклонена.</p>
<h2>GPU: прямые и обратные сравнения</h2>
<p>Полное время render с барьером, мс; медиана / p95 / p99 / max. Небольшие изменения порядка нескольких процентов здесь нельзя уверенно отделить от вариации облачной машины.</p>'''
body+=table(['Протокол','Сценарий','Вариант','N','Время'],all_gpu)
body+='''<p>forest32 сократил геометрию стартового кадра примерно с 1,86 до 1,68 млн треугольников, но повысил calls с 1154 до 1369; стабильного общего ускорения нет. backdrop16 убрал только ~41 тыс. треугольников, добавив ~322 calls. Это примеры, почему счётчики не заменяют замер времени.</p>
<p>Диагностическое скрытие всего terrain/far/backdrop: 3,36 → 0,80 с. Только far/backdrop: 3,36 → 2,09 с, при этом итоговый RGB изменяется всего у 843 из 230400 пикселей. Это указывает на дорогую обработку преимущественно скрытого дальнего фона в данной среде. Отключение теней даёт гораздо меньшую разницу (~3,32 → 2,95 с). Ни одно из этих отключений не предлагается игроку.</p>
<h2>Качество и движение</h2>
<p>glint и zero-lights в сравниваемых статических кадрах дали точное RGBA-совпадение. forest32 меняет несколько пикселей в одном ракурсе из-за порядка растеризации; в другом кадр совпадает. Увеличения FPS, оправдывающего перенос этих проб, не подтверждено. far-last также не дал надёжной пользы и изменяет отдельные пиксели, поэтому не выбран.</p>
<p>PCF без цветовой записи оставляет прежнюю depth-текстуру: статические кадры совпали, но выигрыш меняет знак между сценами. В движении 7 из 8 кадров совпали; первый отличается на 62 RGB-пикселя, максимум 87/255. Причина не установлена — проба не готова к переносу. Карта 1536² вместо 2048² — явный компромисс: шаг теневой сетки в 90-метровой области растёт с ~4,4 до ~5,9 см, края теней становятся мягче/ступенчатее. В одном коротком ракурсе быстрее, в метели медленнее; в приоритет не входит.</p>
<p>Дополнительно записаны 8 точек движения камеры через границы чанков, фиксированы seed, 13:00, экспозиция, солнце и разрешение. Все попиксельные метрики — в pixel-comparison.csv. Положительные point/spot lights отдельно проверены с нулевым shader guard: точное совпадение RGBA. Это дискретная последовательность ракурсов; полноценный аппаратный 60-FPS визуальный QA не выполнен.</p>'''
body+=image('pcf-spawn-0-base.png','Исходная карта теней 2048²')+image('pcf-spawn-0-shadow1536.png','Карта теней 1536²: отдельный компромисс качества')
body+=image('motion-3-base.png','Движение, точка 3: базовый кадр')+image('motion-3-shadow1536.png','Тот же ракурс: карта 1536²')
body+='''<h2>Память, GC, фоновые задачи</h2>
<p>В базовом старте 319 rigid bodies и 2100 colliders; после сценариев изменения счётчиков соответствуют разбитому стеклу, добавленным 100 брёвнам и рубке. CPU-последовательность после принудительного GC: JS heap примерно 44–46 МБ, backing storage 189–198 МБ. Это ограниченный маршрут, а не доказательство отсутствия всех утечек. Рост поля следов и текстур ожидаем и сохраняет историю игрока.</p>
<p>Worker рельефа остался включён. В настоящей ходьбе завершены 48 задач, discarded=0, readyChunks=169. Медиана установки в главном потоке ниже разрешения таймера, p99 на кадр около 0,1 мс, максимум 0,3 мс. Не накоплена очередь старых заданий. В большой последовательности completed доходил до 75 при тех же 169 readyChunks. Полная длительность самого worker-генератора и hardware GPU upload не изолированы.</p>
<p>CPU profiles сохранены для всех сценариев, включая GC. Сопоставление каждого пика кадра с отдельным событием GC не доказано. Производственная дисциплина dispose сохранена; проверки instancing охватывают освобождение удалённых групп, рост и повторное заполнение. Для forest32 исходный тест падал на фиксированном предположении о 128-метровой вместимости; адаптированная проверка сохраняет все шесть смысловых проверок и прошла. Исходный тест не изменён.</p>
<h2>Что делать и что отложить</h2>
<ul><li><b>Без видимых потерь:</b> scoped-reader снега и устранение повторной работы thermal.aggregate. Остальные сохранённые без потерь пробы требуют убедительного времени на целевом GPU, до переноса.</li>
<li><b>Небольшой компромисс:</b> 1536² тени проверены отдельно, преимущества недостаточно. Разрешение экрана, дальности, густота, эффекты и точность симуляции не понижались ради результатов.</li>
<li><b>Дорогая архитектура:</b> полный погодный refresh в Worker с отдельным контролем ревизий, контактным быстрым путём и бюджетом установки. Второе направление — скрытая работа дальнего фона; нужны аппаратный профиль и точная проверка глубины/порядка проходов. Отключать фон или менять дальность не требуется для исследования.</li>
<li><b>Проверено, но пользы не доказано:</b> ранний выход нулевого блеска, ветвь нулевых ламп, лес 32 м, фон 16 ячеек, запись только depth для PCF, поздняя отрисовка packed base, поздняя отрисовка far, карта теней 1536²; суммирование знаменателей тепла отклонено как более медленное.</li></ul>
<h2>Версии</h2>'''
body+=table(['Локальная ветка','Точный SHA'],[[esc(n),'<code>'+sha+'</code>'] for n,sha in branches.items()])
body+='<h2>Карточки графических и отклонённых гипотез</h2>'
body+=table(['Код и лишняя работа','Изменение, механизм и результат','Цена и риск'],[
 ['<code>terrain.ts / makeGroundMaterial</code>: расчёт glint после 28 м, где множитель уже нулевой.','Условие до pow/normalize/reflect. Ожидалось меньше ALU. Статические RGBA совпали; устойчивого времени нет.','Низкая сложность; геометрия/механика/память прежние. Время компиляции отдельно не измерено. Риск изменения шейдерной арифметики, требует QA GPU.'],
 ['<code>effects.ts</code> и <code>lights_fragment_begin</code>: пять точечных ламп и spot остаются в shader pool при нулевой интенсивности.','Пропуск блока прямого освещения при точном zero color. Число ламп постоянно, новые варианты при включении света не появляются. Статика и положительные лампы совпали; ускорение не доказано.','Средняя сложность, зависимость от конкретного Three 0.186.1. Постоянные буферы/механика прежние; shader compile cost не выделен. Не менять pool вслепую — он предотвращает прежние recompilation stalls.'],
 ['<code>forest.ts / InstanceChunks</code>: 128-м группы отправляют часть невидимых экземпляров.','32-м группы, та же геометрия и плотность. Ожидалось точнее отсечение обеих камер. Треугольников меньше, calls больше; выигрыша в обеих сценах нет.','Больше групп, bounds и instance-буферов; нагрузка CPU/метаданные могут расти. Два пикселя одного статического кадра отличаются. Рубка не менялась. Низкая цена кода, средний риск производительности.'],
 ['<code>terrain.ts / buildBackdrop</code>: уже существующие плитки 64×64 ячейки дают консервативное отсечение.','Плитки 16×16 с теми же треугольниками и общими нормалями. Минус ~41 тыс. треугольников, плюс ~322 вызова. Малый шумный результат не выбран.','Общие позиции/нормали не дублируются; геометрий/индексных объектов больше. CPU при создании/обходе может стать дороже; загрузка отдельно не замерена. Низкая цена, средний риск calls на реальной карте.'],
 ['<code>WebGLShadowMap</code>: PCF читает depthTexture, colour attachment не используется освещением.','В <code>renderBufferDirect</code> для PCF-камеры отключена material.colorWrite с немедленным восстановлением. Экономия bandwidth не дала устойчивого выигрыша.','Постоянная память карты не сокращается, colour attachment всё равно выделен. Механика прежняя. Первый из восьми движущихся кадров отличается на 62 пикселя; причина не установлена. Средняя цена, риск состояния renderer.'],
 ['<code>sky.ts</code>: 2048² shadow map.','Явно понижена до 1536². Ожидалось меньше raster/bandwidth. Один ракурс быстрее, метель медленнее.','Площадь карты и её предполагаемые storage-затраты меньше на 43,75%; реальная VRAM не измерялась. 90-м область и сцена прежние, точность/мягкость краёв меняется. Низкая сложность, заметный на близком снегу компромисс, не рекомендован.'],
 ['<code>terrain.ts / attachBase</code>: packed base может шейдиться под снежной поверхностью.','Runtime packed-last ставит renderOrder=2. Ожидалось использовать depth rejection. Статический кадр совпал, малое изменение времени неотделимо от шума.','Механика, память и загрузка прежние. Низкая сложность; возможен другой выбор цвета при равной глубине. Исходникового коммита этой пробы нет — база + записанный runtime-конфиг.'],
 ['<code>terrain.ts / buildFar, buildBackdrop</code>: дальние поверхности обрабатываются, хотя почти все их пиксели скрыты.','far-last переносит непрозрачный far/backdrop после близких поверхностей. Ожидалось меньше overdraw. Проба стала шумно медленнее и изменила 15 пикселей одного кадра; отклонена.','Геометрия, memory и загрузка прежние. Малая цена кода; риск порядка/совпадающей глубины дальних граней. Изменения near/far clipping не делались.'],
 ['<code>thermal.ts / step</code>: суммы коэффициентов одинаковы в трёх проходах solver.','Суммы рассчитаны один раз на шаг в порядке CSR. Данные точно совпадают, но пары не ускорились; несколько медленнее.','Два Float64-буфера по 4275 элементов: +68,4 КБ на thermal instance. Низкая/средняя сложность, риск порядка float-операций проверен; проигрыш времени исключает перенос.'],
])
body+='''<p>GPU-строки с packed-last и диагностическими отключениями — runtime-конфигурации базового SHA и версии скрипта, а не производственные изменения. Исходниковые эквиваленты основных проб собраны отдельно. SHA с изменениями не объявляются готовыми к выпуску; Kimi и QA целевой видеокарты не выполнялись.</p>
<h2>Воспроизведение</h2><p>Полные команды, сценарии, данные, скрипты, source-only patches и git bundle находятся рядом с отчётом. Браузеры запускать последовательно.</p>
<pre><code>export RESEARCH_ROOT="$PWD"
mkdir -p results baseline builds
git clone https://github.com/depthd/nimbleintheforest.git repo
git -C repo fetch ../experiments.bundle 'refs/heads/*:refs/heads/*'
git -C repo switch --detach '''+BASE+'''
(cd repo &amp;&amp; npm ci &amp;&amp; npm run build)
git -C repo archive '''+BASE+''' | tar -x -C baseline
ln -s ../repo/node_modules baseline/node_modules
node serve.cjs repo/dist 5196
# В другом терминале, с тем же RESEARCH_ROOT:
node survey.cjs
node cpu-survey.cjs base
SCENARIOS=forest-walk,blizzard-walk N=1200 node cpu-survey.cjs base-walk
node paired-render.cjs
# Пример отдельного кандидата:
git -C repo switch task/PERF-RESEARCH-20261116-snow-reader
(cd repo &amp;&amp; npm run build -- --outDir "$RESEARCH_ROOT/builds/snow-reader")
node serve.cjs builds 5197
SCENARIOS=forest-walk,blizzard-walk N=1200 URL=http://127.0.0.1:5197/snow-reader/ node cpu-survey.cjs snow-reader-walk
node snow-reader-compare.cjs
# Тепловые пары:
git -C repo switch task/PERF-RESEARCH-20261116-thermal-aggregate
node thermal-compare.cjs repo baseline
# Дополнительные графические протоколы:
PREFIX=pcf SCENARIOS=spawn,blizzard MODES=base,no-shadow-color,shadow1536,no-shadows-diagnostic N=4 ROUNDS=1 node paired-render.cjs
PREFIX=gpu-diagnostic SCENARIOS=spawn MODES=no-shadow-color,base,no-terrain-diagnostic,no-far-diagnostic,no-forest-diagnostic,packed-last N=5 ROUNDS=1 node paired-render.cjs
PREFIX=backdrop SCENARIOS=spawn MODES=base,backdrop16 N=3 ROUNDS=2 node paired-render.cjs
PREFIX=far-order SCENARIOS=spawn MODES=base,far-last N=3 ROUNDS=2 node paired-render.cjs
node motion-visual.cjs</code></pre>
<h2>Проверки и непроверенное</h2>
<p>Для исходниковых кандидатов выполнены production build и repo-check точного SHA; relevant tests: terrain geometry, spatial geometry, trails, snow, snow-cover, thermal equivalence; forest32 отдельно адаптирован к новому размеру группы. Логи и точные guard-результаты приложены. История required ancestor 450184d сохранена. Повторный fetch не изменил интеграционный SHA.</p>
<p>Ограничения: только один seed, малая графическая выборка, облачная CPU-конкуренция, SwiftShader вместо видеокарты, ограниченная длина маршрута и отсутствие совместного замера двух рекомендуемых правок. CPU-скрипт использует управляемое время и отключённый render; не выдавать его результат за FPS игры. Для третьего направления нет кандидата Worker и измеренного процента ускорения. Изменения освещения, разрушений, долгой игры и всех погодных переходов на целевом аппаратном GPU остаются QA следующей задачи.</p>
'''
style='''body{max-width:1000px;margin:36px auto;padding:0 20px;color:#17212b;background:white;font:16px/1.5 system-ui,sans-serif}h1{font-size:30px}h2{margin-top:32px;font-size:22px}code,pre{font:13px/1.5 ui-monospace,monospace}pre{white-space:pre-wrap;background:#f2f4f6;padding:16px}table{border-collapse:collapse;width:100%;font-size:13px;margin:16px 0}th,td{padding:9px 10px;text-align:left;vertical-align:top;border-bottom:1px solid #d5dce2}th{background:#edf2f6}td code{overflow-wrap:anywhere}tr{break-inside:avoid}.scroll{overflow-x:auto}img{max-width:640px;width:100%;height:auto}figure{margin:24px 0}figcaption{font-size:13px}a{color:#1259a5}@media print{body{margin:0;padding:0;max-width:none;font-size:10pt}h2{break-after:avoid}pre{font-size:8pt}table{font-size:8pt}.scroll{overflow:visible}figure{break-inside:avoid}thead{display:table-header-group}}'''
(OUT/'report.html').write_text('<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Исследование производительности nimbleintheforest</title><style>'+style+'</style><body>'+body+'</body></html>')
print(json.dumps({'report':str(OUT/'report.html'),'cpuSummaryRows':len(summary_rows),'gpuSummaryRows':len(all_gpu),'pixelComparisons':len(pixelrows),'branches':len(branches)},ensure_ascii=False))
