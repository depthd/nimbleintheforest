const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const {chromium}=require('playwright'),fs=require('node:fs');
const {install,setup}=require('./paired-render.cjs'),OUT=require('node:path').join(RESEARCH_ROOT, "results");
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{
 const page=await browser.newPage({viewport:{width:640,height:360},deviceScaleFactor:1}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.requestAnimationFrame=()=>0;let s=123456789;Math.random=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};});
 await page.goto('http://127.0.0.1:5196/?test=1&seed=42&hour=13&weather=clear');await page.waitForFunction(()=>window.__game,null,{timeout:300000,polling:100});
 const result={errors,frames:[]};
 // A camera sweep across both the old/new chunk boundaries; each frame compares
 // the same scene/camera/sun. Snow glints also cross their 28 m zero-contribution limit.
 for(let frame=0;frame<8;frame++){
  await page.evaluate(setup,'forest');await page.evaluate(frame=>{const {G}=window.__game,x=124+frame*1.25,z=48;window.__game.teleport(x,G.terrain.heightAt(x,z)+.15,z);window.__game.lookAt(x+3,G.terrain.heightAt(x,z)-.3,z-9);G.sky.update();G.terrain.update(G.camera.position,400);G.forest.update(G.player.pos,true);G.camera.updateMatrixWorld(true);},frame);
  for(const mode of (process.env.MODES||'base,no-shadow-color,shadow1536').split(',')){
   await page.evaluate(install,mode);
   const data=await page.evaluate(()=>{
    const {G}=window.__game,r=G.renderer,gl=r.getContext();r.clear();r.render(G.scene,G.camera);const a=new Uint8Array(640*360*4);gl.readPixels(0,0,640,360,gl.RGBA,gl.UNSIGNED_BYTE,a);let h=2166136261;for(const v of a)h=Math.imul(h^v,16777619)>>>0;let s='';for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode(...a.subarray(i,i+32768));let objects=0,instanceBytes=0;G.scene.traverse(o=>{objects++;if(o.instanceMatrix)instanceBytes+=o.instanceMatrix.array.byteLength;});return {hash:h,raw:btoa(s),objects,instanceBytes,calls:r.info.render.calls,triangles:r.info.render.triangles,camera:{position:G.camera.position.toArray(),quaternion:G.camera.quaternion.toArray()}};
   });
   fs.writeFileSync(`${OUT}/motion-${frame}-${mode}.rgba`,Buffer.from(data.raw,'base64'));delete data.raw;result.frames.push({frame,mode,...data});fs.writeFileSync(`${OUT}/motion-visual.json`,JSON.stringify(result,null,2));console.log(frame,mode,data.hash);
  }
 }
 // Positive lights must still contribute, without changing the fixed light count.
 await page.evaluate(setup,'home');await page.evaluate(()=>{const {G}=window.__game;G.fx.lights[0].position.set(-1,G.house.Y0+1.8,-1);G.fx.lights[0].intensity=8;G.fx.spot.intensity=6;});
 for(const mode of ['base','zero-lights']){await page.evaluate(install,mode);const p=await page.evaluate(()=>{const {G}=window.__game,r=G.renderer,gl=r.getContext();r.clear();r.render(G.scene,G.camera);const a=new Uint8Array(640*360*4);gl.readPixels(0,0,640,360,gl.RGBA,gl.UNSIGNED_BYTE,a);let s='';for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode(...a.subarray(i,i+32768));return btoa(s);});fs.writeFileSync(`${OUT}/active-lights-${mode}.rgba`,Buffer.from(p,'base64'));}
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
