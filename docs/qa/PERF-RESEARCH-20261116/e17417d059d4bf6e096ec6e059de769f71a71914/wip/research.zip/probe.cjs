const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const {chromium}=require('playwright'), fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try {
 const page=await browser.newPage({viewport:{width:640,height:360},deviceScaleFactor:1});
 page.on('pageerror',e=>console.error(e));
 await page.addInitScript(()=>{window.requestAnimationFrame=cb=>{window.__next=cb;return 1;};let s=123456789;Math.random=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};});
 const start=Date.now();await page.goto('http://127.0.0.1:5196/?test=1&seed=42&hour=13&weather=clear');
 await page.waitForFunction(()=>window.__game,null,{timeout:300000,polling:100});
 const data=await page.evaluate(()=>{
  const {G}=window.__game, gl=G.renderer.getContext(),debug=gl.getExtension('WEBGL_debug_renderer_info');
  const types={};G.scene.traverse(o=>{types[o.type]=(types[o.type]||0)+1;});
  return {renderer:debug&&gl.getParameter(debug.UNMASKED_RENDERER_WEBGL),vendor:debug&&gl.getParameter(debug.UNMASKED_VENDOR_WEBGL),version:gl.getParameter(gl.VERSION),extensions:gl.getSupportedExtensions(),ua:navigator.userAgent,dpr:devicePixelRatio,canvas:[gl.drawingBufferWidth,gl.drawingBufferHeight],viewport:[innerWidth,innerHeight],position:G.player.pos.toArray(),Y0:G.house.Y0,time:G.time,settings:G.settings,types,render:G.renderer.info.render,memory:G.renderer.info.memory,heap:performance.memory&&{used:performance.memory.usedJSHeapSize,total:performance.memory.totalJSHeapSize},terrain:G.terrain.streamingStats(),snow:G.snow.renderer.stats(),forest:{trees:G.forest.trees.length,colliders:G.forest.colliders.size},houseEntities:G.entities.list.filter(e=>e.inWorld&&Math.hypot(e.position().x,e.position().z)<10).map(e=>({id:e.id,kind:e.kind,defId:e.defId,p:e.position().toArray()})).slice(0,60),physics:{bodies:G.world.bodies.len(),colliders:G.world.colliders.len()},warmup:performance.getEntriesByName('startup-graphics','measure').map(e=>e.duration)};
 });data.readyMs=Date.now()-start;
 fs.writeFileSync(require('node:path').join(RESEARCH_ROOT, "results/probe.json"),JSON.stringify(data,null,2));console.log(JSON.stringify(data,null,2));
 await page.screenshot({path:require('node:path').join(RESEARCH_ROOT, "results/spawn.png")});
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
