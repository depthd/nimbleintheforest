const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const http = require('node:http'), fs = require('node:fs'), path = require('node:path');
const root = path.resolve(process.argv[2]), port = Number(process.argv[3] || 5196);
const types = {'.html':'text/html','.js':'text/javascript','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.glb':'model/gltf-binary','.json':'application/json'};
http.createServer((req,res)=>{
  const file = path.join(root, decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  const target = file.endsWith('/') ? file+'index.html' : file;
  if(!target.startsWith(root+'/')) {res.writeHead(403).end(); return;}
  fs.readFile(target,(err,data)=>{if(err){res.writeHead(404).end(); return;}res.setHeader('Content-Type',types[path.extname(target)]||'application/octet-stream');res.end(data);});
}).listen(port,'127.0.0.1',()=>console.log(JSON.stringify({root,port})));
