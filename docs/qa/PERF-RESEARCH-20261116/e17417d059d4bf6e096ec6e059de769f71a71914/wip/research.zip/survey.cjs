const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const {chromium}=require('playwright'),fs=require('node:fs');
const OUT=require('node:path').join(RESEARCH_ROOT, "results");
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try {
 const page=await browser.newPage({viewport:{width:640,height:360},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
   let seed=123456789;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
   window.__nativeRAF=requestAnimationFrame.bind(window); window.__survey={samples:[],enabled:false,previous:null};
   window.requestAnimationFrame=cb=>window.__nativeRAF(now=>{
     const s=window.__survey, enabled=s.enabled;const t=performance.now();s.current={};
     if(s.route)s.route(s.index++);
     cb(now);
     if(enabled){s.samples.push({interval:s.previous===null?null:now-s.previous,total:performance.now()-t,...s.current});s.previous=now;}
   });
 });
 const start=Date.now();await page.goto('http://127.0.0.1:5196/?test=1&seed=42&hour=13&weather=clear');
 await page.waitForFunction(()=>window.__game,null,{timeout:300000,polling:100});
 const readyMs=Date.now()-start;console.log("ready",readyMs);
 await page.evaluate(()=>{
  const {G}=window.__game,s=window.__survey;
  const wrap=(o,k,name)=>{if(!o||typeof o[k]!=='function')return;const fn=o[k];o[k]=function(...a){const t=performance.now();try{return fn.apply(this,a);}finally{if(s.enabled)s.current[name]=(s.current[name]||0)+performance.now()-t;}};};
  for(const key of ['weather','fires','thermal','lake','build','body','entities','resting','forest','player','snow','terrain','cliffs','structures','corpses','animals','interact','sky','fx','vm','audio','hud','recorder']){
   const o=G[key];for(const m of ['update','step','stream','sync','updateFalling','physics','updateCamera','renderHands','present','captureFrame','beginTick','endTick','cull'])wrap(o,m,key+'.'+m);
  }
  wrap(G.world,'step','world.step');wrap(G.player.avatar,'update','avatar.update');wrap(G.player.avatar,'renderHands','avatar.renderHands');wrap(G.house,'updateDoor','door');
  wrap(G.scene,'updateMatrixWorld','scene.matrices');wrap(G.renderer,'render','render.submit');wrap(G.snow.renderer,'refresh','trail.refresh');wrap(G.snow,'raycast','snow.raycast');
  const render=G.renderer.render;G.renderer.render=function(...a){const r=render.apply(this,a);if(s.enabled){s.current.calls=this.info.render.calls;s.current.triangles=this.info.render.triangles;}return r;};
  s.setup=name=>{
   s.enabled=false;s.route=null;s.index=0;G.settings.weatherLock=name==='blizzard'?'blizzard':'clear';G.weather.setType(G.settings.weatherLock,true);
   const api=window.__game;
   if(name==='home'){api.teleport(0,G.house.Y0+.03,1.5);api.lookAt(-3.6,G.house.Y0+1,-3.25);G.house.door.data.open=true;}
   if(name==='forest'||name==='blizzard'){
    s.route=i=>{const x=118+Math.min(i,300)*.7,z=48;api.teleport(x,G.terrain.heightAt(x,z)+.12,z);api.lookAt(x+8,G.terrain.heightAt(x+8,z)-.2,z-10);};
   }
   if(name==='overview'){api.teleport(80,G.terrain.heightAt(80,80)+160,80);api.lookAt(0,G.house.Y0,0);G.paused=true;}
   if(name==='pile'){
    api.teleport(12,G.terrain.heightAt(12,10)+.1,10);api.lookAt(16,G.terrain.heightAt(16,10)+.5,10);
    for(let i=0;i<100;i++)G.entities.spawnItem('log',new window.__game.THREE.Vector3(16+(i%5)*.22,G.terrain.heightAt(16,10)+1+Math.floor(i/25)*.25,10+(Math.floor(i/5)%5)*.22));
   }
   if(name!=='overview')G.paused=false;
  };
 });
 const cdp=await page.context().newCDPSession(page);await cdp.send('Profiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:1000});
 const result={readyMs,errors,scenarios:{}};
 for(const scenario of (process.env.SCENARIOS||'home,forest,overview,blizzard,pile').split(',')){
   await page.evaluate(n=>window.__survey.setup(n),scenario);
   // Fixed sample counts, natural RAF; unmeasured setup and 20 warm frames.
   await page.evaluate(()=>{window.__survey.warm=0;window.__survey.route0=window.__survey.route;const r=window.__survey.route;window.__survey.route=i=>{r?.(i);window.__survey.warm++;};});
   await page.waitForFunction(()=>window.__survey.warm>=3,null,{timeout:180000,polling:50});
   await page.evaluate(()=>{const s=window.__survey;s.route=s.route0;s.enabled=true;s.samples=[];s.previous=null;});
   await cdp.send('Profiler.start');
   await page.waitForFunction(()=>window.__survey.samples.length>=20,null,{timeout:300000,polling:50});
   const {profile}=await cdp.send('Profiler.stop');fs.writeFileSync(`${OUT}/survey-${scenario}.cpuprofile`,JSON.stringify(profile));
   result.scenarios[scenario]=await page.evaluate(()=>{const s=window.__survey;s.enabled=false;const {G}=window.__game;return {samples:s.samples,position:G.player.pos.toArray(),time:G.time,physics:{bodies:G.world.bodies.len(),colliders:G.world.colliders.len()},terrain:G.terrain.streamingStats(),snow:G.snow.renderer.stats(),memory:G.renderer.info.memory,heap:performance.memory.usedJSHeapSize};});
   await page.screenshot({path:`${OUT}/survey-${scenario}.png`});
   fs.writeFileSync(`${OUT}/survey.json`,JSON.stringify(result,null,2));
   const a=result.scenarios[scenario].samples;const summary={};for(const k of Object.keys(a[0])){const v=a.map(x=>x[k]).filter(x=>typeof x==='number').sort((a,b)=>a-b);summary[k]={p50:v[Math.floor(v.length*.5)],p95:v[Math.floor(v.length*.95)],p99:v[Math.floor(v.length*.99)],max:v.at(-1),mean:v.reduce((a,b)=>a+b,0)/v.length};}
   fs.writeFileSync(`${OUT}/survey-${scenario}-summary.json`,JSON.stringify(summary,null,2));console.log(scenario,JSON.stringify(summary));
 }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
