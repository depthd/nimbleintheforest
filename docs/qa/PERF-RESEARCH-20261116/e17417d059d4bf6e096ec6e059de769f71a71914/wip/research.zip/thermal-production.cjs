const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const {chromium}=require('playwright'),fs=require('node:fs');
const OUT=require('node:path').join(RESEARCH_ROOT, "results");
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{
 const results=[];
 for(const name of ['base','candidate','candidate','base']){
  const ctx=await browser.newContext({viewport:{width:640,height:360},deviceScaleFactor:1}),page=await ctx.newPage();
  await page.addInitScript(()=>{requestAnimationFrame=()=>0;let s=123456789;Math.random=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};});
  await page.goto((name==='base'?'http://127.0.0.1:5196/':'http://127.0.0.1:5197/thermal-aggregate/')+'?test=1&seed=42&hour=13&weather=clear&warmup=0');await page.waitForFunction(()=>window.__game,null,{timeout:180000,polling:100});
  const data=await page.evaluate(()=>{
   const {G}=window.__game;G.house.door.data.open=true;for(const e of G.house.windows)e.data.glass='broken';G.weather.temp=-24;G.weather.wind=14;G.fires.stoveFire.power=8;
   for(let i=0;i<100;i++)G.thermal.update(.2);const samples=[];
   for(let i=0;i<400;i++){const t=performance.now();for(let j=0;j<10;j++)G.thermal.update(.2);samples.push((performance.now()-t)/10);}
   const a=[...samples].sort((a,b)=>a-b),bytes=new Uint8Array(G.thermal.T.buffer);let hash=2166136261;for(const x of bytes)hash=Math.imul(hash^x,16777619)>>>0;
   return {samples,p50:a[200],p95:a[380],p99:a[396],mean:a.reduce((a,b)=>a+b)/a.length,thermalHash:hash};
  });results.push({name,...data});fs.writeFileSync(`${OUT}/thermal-production.json`,JSON.stringify(results,null,2));console.log(name,JSON.stringify({...data,samples:undefined}));await ctx.close();
 }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
