const RESEARCH_ROOT = process.env.RESEARCH_ROOT || __dirname;
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const root=path.resolve(process.argv[2]||require('node:path').join(RESEARCH_ROOT, "repo")),reference=path.resolve(process.argv[3]||require('node:path').join(RESEARCH_ROOT, "baseline"));
const {buildSync}=require(path.join(root,'node_modules/esbuild'));
const load=r=>{const file=path.join(r,'src/game/thermal.ts');const m=new Module(file);m._compile(buildSync({stdin:{contents:fs.readFileSync(file,'utf8')+'\nexport {G};export * as Three from "three";',resolveDir:path.join(root,'src/game'),loader:'ts'},bundle:true,platform:'node',format:'cjs',write:false}).outputFiles[0].text,file);return m.exports;};
const A=load(root),B=load(reference);
function fixture(mod){const {G,Three:T}=mod;Object.assign(G,{house:{Y0:12.345,windows:[{data:{center:new T.Vector3(4.75,13.8,0),inward:new T.Vector3(-1,0,0),w:1.3,h:1.4,glass:'broken',boards:0,cover:null}},{data:{center:new T.Vector3(2,13.8,3.75),inward:new T.Vector3(0,0,-1),w:1.5,h:1.4,glass:'intact',boards:0,cover:null}}],door:{removed:false,data:{open:true,angle:0}},stove:{data:{firePos:new T.Vector3(-3,12.8,-2)}}},weather:{temp:-24,wind:14},fires:{stoveFire:{power:8},list:[]},entities:{list:[]},player:{pos:new T.Vector3(0,12.4,0)}});const t=new mod.Thermal();t.init();return t;}
const a=fixture(A),b=fixture(B);const keys=['T','AH','draft','windowFrost','windowGlassT','zones','num','den','hnum','hden','pendingVapour'];
for(let i=0;i<300;i++){
 for(const mod of [A,B]){const {G}=mod;G.weather.temp=-24+(i%13)*3;G.weather.wind=i%21;G.fires.stoveFire.power=i%11;for(const w of G.house.windows){w.data.glass=i%3?'broken':'intact';w.data.cover=i%4===0?{}:null;w.data.boards=i%3;}G.house.door.data.open=i%2===0;G.house.door.removed=i%5===0;G.house.doorway={data:{cover:i%2?{}:null}};}
 const dt=[.2,1/60,12,60,0][i%5];a.update(dt);b.update(dt);
 for(const k of keys)assert.deepEqual(a[k],b[k],`step ${i} ${k}`);
 assert.deepEqual(a.faces.map(f=>[f.Ts,f.glassT]),b.faces.map(f=>[f.Ts,f.glassT]));
}
console.log('PASS exact arrays, surfaces and aggregate output across 300 changing-window/door/weather/fire steps, including zero and 60-second steps');
const results=[];
for(let round=0;round<4;round++)for(const [name,mod] of round%2?[['candidate',A],['base',B]]:[['base',B],['candidate',A]]){
 const t=fixture(mod);for(let i=0;i<200;i++)t.update(.2);const samples=[];
 for(let i=0;i<1200;i++){const start=performance.now();t.update(.2);samples.push(performance.now()-start);}const sorted=[...samples].sort((a,b)=>a-b);
 results.push({round,name,samples,p50:sorted[600],p95:sorted[1140],p99:sorted[1188],mean:samples.reduce((a,b)=>a+b)/samples.length});
 console.log(JSON.stringify({...results.at(-1),samples:undefined}));
}
fs.writeFileSync(require('node:path').join(RESEARCH_ROOT, "results/thermal-compare.json"),JSON.stringify(results,null,2));
